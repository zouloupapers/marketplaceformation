/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#FBF8E9',
          100: '#F7F1D4',
          200: '#EFE3AA',
          300: '#E6D57F',
          400: '#DEC655',
          500: '#D4AF37', // Main primary color
          600: '#B38D20',
          700: '#8E6C18',
          800: '#69510F',
          900: '#453508',
        },
        secondary: {
          50: '#E9EAEF',
          100: '#D4D6E0',
          200: '#A9ADC1',
          300: '#7F84A2',
          400: '#555C83',
          500: '#1E2761', // Main secondary color
          600: '#182051',
          700: '#121940',
          800: '#0D1230',
          900: '#080B20',
        },
        accent: {
          50: '#FEEBE5',
          100: '#FDD7CC',
          200: '#FBAF99',
          300: '#F98866',
          400: '#F76033',
          500: '#F53900', // Main accent color
          600: '#C62E00',
          700: '#972300',
          800: '#681800',
          900: '#3A0E00',
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        serif: ['Playfair Display', 'serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in',
        'slide-up': 'slideUp 0.5s ease-out',
        'slide-right': 'slideRight 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideRight: {
          '0%': { transform: 'translateX(-20px)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};