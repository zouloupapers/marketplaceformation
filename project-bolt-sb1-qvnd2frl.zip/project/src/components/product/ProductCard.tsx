import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../../types';
import { ShoppingBag } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <div className="group">
      <div className="relative overflow-hidden rounded-lg bg-gray-100 mb-3">
        <Link to={`/product/${product.id}`}>
          <img
            src={product.images[0]}
            alt={product.name}
            className="h-64 w-full object-cover object-center transition-transform duration-300 group-hover:scale-105"
          />
        </Link>
        
        {/* Quick add button overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-3 bg-white bg-opacity-80 backdrop-blur-sm transform translate-y-full transition-transform duration-300 group-hover:translate-y-0">
          <Link
            to={`/product/${product.id}`}
            className="flex items-center justify-center space-x-2 bg-secondary-500 text-white py-2 rounded-md w-full hover:bg-secondary-600 transition-colors"
          >
            <ShoppingBag size={16} />
            <span>View Product</span>
          </Link>
        </div>

        {/* Tags */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.new && (
            <span className="bg-accent-500 text-white text-xs px-2 py-1 rounded">
              NEW
            </span>
          )}
          {product.featured && (
            <span className="bg-primary-500 text-secondary-900 text-xs px-2 py-1 rounded">
              FEATURED
            </span>
          )}
        </div>
      </div>

      <div>
        <Link to={`/product/${product.id}`} className="hover:text-primary-500 transition-colors">
          <h3 className="font-semibold text-lg">{product.name}</h3>
        </Link>
        <p className="text-lg font-semibold text-secondary-500 mt-1">
          ${product.price.toFixed(2)}
        </p>
        <div className="flex items-center mt-1">
          <div className="flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <svg
                key={i}
                className={`w-4 h-4 ${
                  i < Math.floor(product.rating || 0) 
                    ? 'text-primary-500' 
                    : i < (product.rating || 0) 
                      ? 'text-primary-300' 
                      : 'text-gray-300'
                }`}
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            ))}
          </div>
          {product.rating && (
            <span className="text-xs text-gray-500 ml-1">
              ({product.rating})
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;