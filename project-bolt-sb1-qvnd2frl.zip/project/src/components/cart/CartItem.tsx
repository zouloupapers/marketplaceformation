import React from 'react';
import { Minus, Plus, Trash2 } from 'lucide-react';
import { CartItem as CartItemType } from '../../types';
import { useCart } from '../../context/CartContext';

interface CartItemProps {
  item: CartItemType;
}

const CartItem: React.FC<CartItemProps> = ({ item }) => {
  const { removeFromCart, updateQuantity } = useCart();
  const { product, quantity, size, color } = item;

  const handleRemove = () => {
    removeFromCart(product.id, size);
  };

  const decreaseQuantity = () => {
    if (quantity > 1) {
      updateQuantity(product.id, size, quantity - 1);
    } else {
      removeFromCart(product.id, size);
    }
  };

  const increaseQuantity = () => {
    updateQuantity(product.id, size, quantity + 1);
  };

  return (
    <div className="flex py-4 border-b border-gray-200">
      <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">
        <img
          src={product.images[0]}
          alt={product.name}
          className="h-full w-full object-cover object-center"
        />
      </div>

      <div className="ml-4 flex flex-1 flex-col">
        <div>
          <div className="flex justify-between text-base font-medium text-secondary-800">
            <h3>{product.name}</h3>
            <p className="ml-4">${(product.price * quantity).toFixed(2)}</p>
          </div>
          <div className="mt-1 text-sm text-gray-500">
            {color && <span>Color: {color}</span>}
            {color && size && <span className="mx-1">|</span>}
            {size && <span>Size: {size}</span>}
          </div>
        </div>
        
        <div className="flex flex-1 items-end justify-between text-sm">
          <div className="flex items-center border rounded-md">
            <button
              type="button"
              className="p-1 text-gray-600 hover:text-secondary-800"
              onClick={decreaseQuantity}
            >
              <Minus size={16} />
            </button>
            <span className="px-2 py-1 text-center w-8">{quantity}</span>
            <button
              type="button"
              className="p-1 text-gray-600 hover:text-secondary-800"
              onClick={increaseQuantity}
            >
              <Plus size={16} />
            </button>
          </div>

          <button
            type="button"
            className="font-medium text-accent-500 hover:text-accent-600 flex items-center"
            onClick={handleRemove}
          >
            <Trash2 size={16} className="mr-1" />
            Remove
          </button>
        </div>
      </div>
    </div>
  );
};

export default CartItem;