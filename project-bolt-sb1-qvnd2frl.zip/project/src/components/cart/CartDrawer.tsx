import React from 'react';
import { X, ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import CartItem from './CartItem';
import Button from '../ui/Button';

const CartDrawer: React.FC = () => {
  const { cart, isCartOpen, setIsCartOpen, subtotal, totalItems } = useCart();

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 overflow-hidden z-50">
      <div className="absolute inset-0 overflow-hidden">
        {/* Background overlay */}
        <div 
          className="absolute inset-0 bg-secondary-900 bg-opacity-50 transition-opacity" 
          onClick={() => setIsCartOpen(false)}
        ></div>
        
        <div className="fixed inset-y-0 right-0 pl-10 max-w-full flex">
          <div className="w-screen max-w-md">
            <div className="h-full flex flex-col bg-white shadow-xl overflow-y-scroll">
              <div className="flex-1 py-6 overflow-y-auto px-4 sm:px-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-secondary-800">Shopping Cart</h2>
                  <button
                    type="button"
                    className="p-1 rounded-md text-gray-400 hover:text-gray-500"
                    onClick={() => setIsCartOpen(false)}
                  >
                    <span className="sr-only">Close panel</span>
                    <X size={24} aria-hidden="true" />
                  </button>
                </div>

                <div className="mt-8">
                  {cart.length > 0 ? (
                    <div className="flow-root">
                      <ul className="-my-6 divide-y divide-gray-200">
                        {cart.map((item) => (
                          <li key={`${item.product.id}-${item.size}`} className="py-6">
                            <CartItem item={item} />
                          </li>
                        ))}
                      </ul>
                    </div>
                  ) : (
                    <div className="py-12 text-center">
                      <div className="inline-block p-3 rounded-full bg-gray-100 mb-4">
                        <ShoppingBag size={32} className="text-secondary-400" />
                      </div>
                      <h3 className="text-lg font-medium text-secondary-800">Your cart is empty</h3>
                      <p className="mt-2 text-gray-500">
                        Looks like you haven't added anything to your cart yet.
                      </p>
                      <div className="mt-6">
                        <Button
                          onClick={() => setIsCartOpen(false)}
                          className="inline-flex items-center"
                        >
                          Continue Shopping
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {cart.length > 0 && (
                <div className="border-t border-gray-200 py-6 px-4 sm:px-6">
                  <div className="flex justify-between text-base font-medium text-secondary-800">
                    <p>Subtotal ({totalItems} {totalItems === 1 ? 'item' : 'items'})</p>
                    <p>${subtotal.toFixed(2)}</p>
                  </div>
                  <p className="mt-0.5 text-sm text-gray-500">
                    Shipping and taxes calculated at checkout.
                  </p>
                  <div className="mt-6">
                    <Link
                      to="/checkout"
                      onClick={() => setIsCartOpen(false)}
                    >
                      <Button
                        fullWidth
                        size="lg"
                      >
                        Checkout
                      </Button>
                    </Link>
                  </div>
                  <div className="mt-4">
                    <button
                      type="button"
                      className="text-secondary-600 hover:text-secondary-800 w-full text-center text-sm"
                      onClick={() => setIsCartOpen(false)}
                    >
                      Continue Shopping
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartDrawer;