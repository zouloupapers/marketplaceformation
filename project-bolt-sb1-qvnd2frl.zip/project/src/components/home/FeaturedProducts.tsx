import React from 'react';
import ProductGrid from '../product/ProductGrid';
import { getFeaturedProducts } from '../../data/products';

const FeaturedProducts: React.FC = () => {
  const featuredProducts = getFeaturedProducts();

  return (
    <div className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-semibold text-secondary-900">
            Featured Products
          </h2>
          <p className="mt-3 text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our handpicked selection of premium items, carefully curated for style and quality.
          </p>
        </div>
        
        <ProductGrid products={featuredProducts} />
      </div>
    </div>
  );
};

export default FeaturedProducts;