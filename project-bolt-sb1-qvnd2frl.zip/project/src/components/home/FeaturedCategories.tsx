import React from 'react';
import { Link } from 'react-router-dom';

const FeaturedCategories: React.FC = () => {
  const categories = [
    {
      id: 'clothing',
      name: 'Clothing',
      image: 'https://images.pexels.com/photos/5325599/pexels-photo-5325599.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      description: 'Premium apparel for every occasion'
    },
    {
      id: 'sneakers',
      name: 'Sneakers',
      image: 'https://images.pexels.com/photos/1456706/pexels-photo-1456706.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      description: 'Performance and style for your feet'
    }
  ];

  return (
    <div className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-serif font-semibold text-secondary-900 mb-8 text-center">
          Shop by Category
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {categories.map((category) => (
            <Link 
              key={category.id}
              to={`/category/${category.id}`}
              className="group overflow-hidden rounded-lg relative"
            >
              <div className="h-80 w-full overflow-hidden rounded-lg">
                <img
                  src={category.image}
                  alt={category.name}
                  className="h-full w-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-secondary-900/70 to-transparent flex flex-col justify-end p-6">
                <h3 className="text-2xl font-serif font-semibold text-white">{category.name}</h3>
                <p className="text-white/90 mt-1">{category.description}</p>
                <div className="mt-4 inline-block">
                  <span className="text-primary-400 font-medium group-hover:text-primary-300 transition-colors flex items-center">
                    Shop Now
                    <svg className="w-5 h-5 ml-2 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                    </svg>
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeaturedCategories;