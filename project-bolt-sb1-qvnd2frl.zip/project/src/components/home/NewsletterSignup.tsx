import React, { useState } from 'react';
import Button from '../ui/Button';

const NewsletterSignup: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simulate form submission
    if (email) {
      setIsSubmitted(true);
      setEmail('');
      
      // Reset after 3 seconds
      setTimeout(() => {
        setIsSubmitted(false);
      }, 3000);
    }
  };

  return (
    <div className="py-16 bg-primary-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:flex lg:items-center lg:justify-between">
          <div className="lg:w-1/2 mb-8 lg:mb-0">
            <h2 className="text-3xl font-serif font-semibold text-secondary-900">
              Join Our Newsletter
            </h2>
            <p className="mt-3 text-lg text-secondary-800 max-w-xl">
              Subscribe to get exclusive updates on new arrivals, special offers, and style tips delivered straight to your inbox.
            </p>
          </div>
          
          <div className="lg:w-1/2">
            {isSubmitted ? (
              <div className="bg-white/20 backdrop-blur-sm rounded-lg p-6 border border-white/30 animate-fade-in">
                <p className="text-secondary-900 font-medium text-lg">
                  Thank you for subscribing!
                </p>
                <p className="text-secondary-800 mt-1">
                  We've sent a confirmation email to your inbox.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="sm:flex">
                <div className="w-full sm:max-w-xs">
                  <label htmlFor="email" className="sr-only">Email address</label>
                  <input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="bg-white/10 backdrop-blur-sm border border-white/30 block w-full px-4 py-3 placeholder-secondary-600 shadow-sm focus:outline-none focus:ring-2 focus:ring-white focus:border-white rounded-md"
                  />
                </div>
                <div className="mt-3 sm:mt-0 sm:ml-3">
                  <Button
                    type="submit"
                    variant="secondary"
                    className="w-full"
                  >
                    Subscribe
                  </Button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewsletterSignup;