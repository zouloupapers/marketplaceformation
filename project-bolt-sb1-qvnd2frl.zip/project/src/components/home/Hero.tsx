import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../ui/Button';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-gray-100 overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/5624986/pexels-photo-5624986.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
          alt="Hero background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-secondary-900/80 to-secondary-900/40"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 py-32 sm:px-6 sm:py-40 lg:px-8">
        <div className="max-w-2xl">
          <h1 className="text-4xl font-serif font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
            Elevate Your Style
          </h1>
          <p className="mt-6 text-xl text-white max-w-lg">
            Discover premium clothing and exclusive sneakers at Shine Shopping. 
            Where fashion meets comfort in perfect harmony.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4">
            <Link to="/category/clothing">
              <Button variant="primary" size="lg">
                Shop Clothing
              </Button>
            </Link>
            <Link to="/category/sneakers">
              <Button variant="outline" size="lg" className="bg-white/20 backdrop-blur-sm border-white text-white hover:bg-white/30">
                Explore Sneakers
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;