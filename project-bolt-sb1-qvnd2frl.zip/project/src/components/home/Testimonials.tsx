import React from 'react';

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      id: 1,
      content: "Shine Shopping has completely transformed my wardrobe! The quality of their clothing is unmatched, and their sneaker collection is always on trend.",
      author: "Jessica K.",
      role: "Fashion Blogger",
      avatar: "https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      id: 2,
      content: "I've been a loyal customer for over two years now. The attention to detail and customer service are exceptional. My go-to place for premium fashion.",
      author: "Michael T.",
      role: "Fitness Instructor",
      avatar: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      id: 3,
      content: "The sneakers I purchased from Shine Shopping are the most comfortable I've ever owned. Great style without compromising on quality or comfort.",
      author: "Sarah J.",
      role: "Graphic Designer",
      avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    }
  ];

  return (
    <div className="py-16 bg-secondary-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-semibold text-secondary-900">
            What Our Customers Say
          </h2>
          <p className="mt-3 text-lg text-gray-600 max-w-2xl mx-auto">
            Don't just take our word for it - hear from our satisfied customers.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div 
              key={testimonial.id} 
              className="bg-white rounded-lg shadow-sm p-6 relative"
            >
              <div className="mb-4">
                <svg width="45" height="36" className="text-primary-300 opacity-70" viewBox="0 0 45 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M13.4 36C11.7 36 10.2 35.4 8.9 34.2C7.6 33 7 31.5 7 29.8C7 28.7 7.2 27.7 7.7 26.8C8.2 25.9 8.8 25.1 9.6 24.4C10.4 23.7 11.2 22.9 12.2 22C13.1 21.1 14 20.1 14.9 19.1C15.8 18.1 16.6 17 17.3 15.8C18 14.7 18.4 13.5 18.5 12.3L18.8 9.4H20.8C20.8 13.2 20.1 16.1 18.8 18.3C17.5 20.5 15.2 22.5 11.9 24.4C11.9 24.5 11.9 24.5 11.9 24.6C11.9 24.6 11.9 24.7 11.9 24.8C11.9 26.7 12.4 28.2 13.4 29.5C14.4 30.8 16 31.4 18.2 31.4C19.3 31.4 20.3 31.2 21.2 30.8C22.1 30.4 22.8 30 23.3 29.7L24.6 33.9C23.7 34.5 22.5 35 21.1 35.4C19.6 35.8 18.3 36 17 36H13.4ZM36.1 36C34.4 36 32.9 35.4 31.6 34.2C30.3 33 29.7 31.5 29.7 29.8C29.7 28.7 29.9 27.7 30.4 26.8C30.9 25.9 31.5 25.1 32.3 24.4C33.1 23.7 33.9 22.9 34.9 22C35.8 21.1 36.7 20.1 37.6 19.1C38.5 18.1 39.3 17 40 15.8C40.7 14.7 41.1 13.5 41.2 12.3L41.5 9.4H43.5C43.5 13.2 42.8 16.1 41.5 18.3C40.2 20.5 37.9 22.5 34.6 24.4C34.6 24.5 34.6 24.5 34.6 24.6C34.6 24.6 34.6 24.7 34.6 24.8C34.6 26.7 35.1 28.2 36.1 29.5C37.1 30.8 38.7 31.4 40.9 31.4C42 31.4 43 31.2 43.9 30.8C44.8 30.4 45.5 30 46 29.7L47.3 33.9C46.4 34.5 45.2 35 43.8 35.4C42.3 35.8 41 36 39.7 36H36.1Z" fill="currentColor"/>
                </svg>
              </div>
              <p className="text-gray-700 mb-6">{testimonial.content}</p>
              <div className="flex items-center">
                <img 
                  src={testimonial.avatar} 
                  alt={testimonial.author}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="ml-3">
                  <h4 className="font-semibold text-secondary-800">{testimonial.author}</h4>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Testimonials;