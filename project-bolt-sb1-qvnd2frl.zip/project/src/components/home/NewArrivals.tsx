import React from 'react';
import { Link } from 'react-router-dom';
import ProductGrid from '../product/ProductGrid';
import Button from '../ui/Button';
import { getNewArrivals } from '../../data/products';

const NewArrivals: React.FC = () => {
  const newProducts = getNewArrivals();

  return (
    <div className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-serif font-semibold text-secondary-900">
              New Arrivals
            </h2>
            <p className="mt-2 text-gray-600">
              The latest additions to our collection
            </p>
          </div>
          <Link to="/new-arrivals">
            <Button variant="outline">
              View All
            </Button>
          </Link>
        </div>
        
        <ProductGrid products={newProducts} />
      </div>
    </div>
  );
};

export default NewArrivals;