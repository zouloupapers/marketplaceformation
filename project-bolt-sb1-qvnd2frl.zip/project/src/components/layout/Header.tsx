import React, { useState, useEffect } from 'react';
import { ShoppingBag, Search, Menu, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../../context/CartContext';

const Header: React.FC = () => {
  const { totalItems, setIsCartOpen } = useCart();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
    // Close search when opening mobile menu
    if (!mobileMenuOpen) setSearchOpen(false);
  };

  const toggleSearch = () => {
    setSearchOpen(!searchOpen);
    // Close mobile menu when opening search
    if (!searchOpen) setMobileMenuOpen(false);
  };

  const handleCartClick = () => {
    setIsCartOpen(true);
    setMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <h1 className="font-serif text-2xl font-bold text-secondary-500">
              <span className="text-primary-500">Shine</span>Shopping
            </h1>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-secondary-800 hover:text-primary-500 transition-colors font-medium">
              Home
            </Link>
            <Link to="/category/clothing" className="text-secondary-800 hover:text-primary-500 transition-colors font-medium">
              Clothing
            </Link>
            <Link to="/category/sneakers" className="text-secondary-800 hover:text-primary-500 transition-colors font-medium">
              Sneakers
            </Link>
            <Link to="/new-arrivals" className="text-secondary-800 hover:text-primary-500 transition-colors font-medium">
              New Arrivals
            </Link>
          </nav>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <button 
              onClick={toggleSearch}
              className="text-secondary-800 hover:text-primary-500 transition-colors p-2"
              aria-label="Search"
            >
              <Search size={20} />
            </button>
            <button 
              onClick={handleCartClick}
              className="text-secondary-800 hover:text-primary-500 transition-colors p-2 relative"
              aria-label="Shopping Cart"
            >
              <ShoppingBag size={20} />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-accent-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </button>
            <button 
              className="md:hidden text-secondary-800 p-2"
              onClick={toggleMobileMenu}
              aria-label="Menu"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div className="py-3 px-4 mt-2 bg-white shadow-md rounded-md animate-fade-in">
            <input
              type="text"
              placeholder="Search for products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full py-2 px-4 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-300"
            />
          </div>
        )}

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 bg-white shadow-md rounded-md mt-2 animate-slide-up">
            <div className="flex flex-col space-y-3 p-4">
              <Link 
                to="/" 
                className="text-secondary-800 hover:text-primary-500 transition-colors py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                to="/category/clothing" 
                className="text-secondary-800 hover:text-primary-500 transition-colors py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                Clothing
              </Link>
              <Link 
                to="/category/sneakers" 
                className="text-secondary-800 hover:text-primary-500 transition-colors py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                Sneakers
              </Link>
              <Link 
                to="/new-arrivals" 
                className="text-secondary-800 hover:text-primary-500 transition-colors py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                New Arrivals
              </Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;