export interface Product {
  id: number;
  name: string;
  price: number;
  category: 'clothing' | 'sneakers';
  subCategory?: string;
  description: string;
  images: string[];
  sizes: string[];
  colors?: string[];
  featured?: boolean;
  new?: boolean;
  rating?: number;
  inStock: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
  size: string;
  color?: string;
}

export type CartContextType = {
  cart: CartItem[];
  addToCart: (product: Product, quantity: number, size: string, color?: string) => void;
  removeFromCart: (productId: number, size: string) => void;
  updateQuantity: (productId: number, size: string, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (isOpen: boolean) => void;
  totalItems: number;
  subtotal: number;
};