import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { SlidersHorizontal, X, ChevronDown } from 'lucide-react';
import { getProductsByCategory } from '../data/products';
import ProductGrid from '../components/product/ProductGrid';

const CategoryPage: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const [products, setProducts] = useState(getProductsByCategory(category as 'clothing' | 'sneakers'));
  const [showFilters, setShowFilters] = useState(false);
  const [priceRange, setPriceRange] = useState([0, 200]);
  const [sortOption, setSortOption] = useState('featured');

  const capitalizedCategory = category ? category.charAt(0).toUpperCase() + category.slice(1) : '';

  useEffect(() => {
    if (category) {
      setProducts(getProductsByCategory(category as 'clothing' | 'sneakers'));
    }
  }, [category]);

  const handleSortChange = (option: string) => {
    setSortOption(option);
    let sortedProducts = [...products];
    
    switch (option) {
      case 'price-low':
        sortedProducts.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        sortedProducts.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        sortedProducts.sort((a, b) => (b.new ? 1 : 0) - (a.new ? 1 : 0));
        break;
      case 'featured':
      default:
        sortedProducts.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        break;
    }
    
    setProducts(sortedProducts);
  };

  const handlePriceChange = (value: number[]) => {
    setPriceRange(value);
    // Filter products by price range
    const filteredProducts = getProductsByCategory(category as 'clothing' | 'sneakers')
      .filter(product => product.price >= value[0] && product.price <= value[1]);
    setProducts(filteredProducts);
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-serif font-semibold">{capitalizedCategory}</h1>
        
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center px-3 py-2 border border-gray-300 rounded-md text-secondary-700 hover:bg-gray-50 md:hidden"
          >
            <SlidersHorizontal size={18} className="mr-2" />
            Filters
          </button>
          
          <div className="relative">
            <select
              value={sortOption}
              onChange={(e) => handleSortChange(e.target.value)}
              className="appearance-none pl-3 pr-10 py-2 border border-gray-300 rounded-md bg-white text-secondary-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="featured">Featured</option>
              <option value="newest">Newest</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
            </select>
            <ChevronDown size={16} className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-500" />
          </div>
        </div>
      </div>
      
      <div className="flex flex-col md:flex-row">
        {/* Filters - Desktop */}
        <div className="hidden md:block w-64 pr-8">
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-3">Price Range</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>${priceRange[0]}</span>
                  <span>${priceRange[1]}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="200"
                  value={priceRange[1]}
                  onChange={(e) => handlePriceChange([priceRange[0], parseInt(e.target.value)])}
                  className="w-full"
                />
              </div>
            </div>
            
            {category === 'clothing' && (
              <div>
                <h3 className="text-lg font-medium mb-3">Category</h3>
                <div className="space-y-2">
                  {['t-shirts', 'pants', 'hoodies', 'shirts', 'jackets'].map((cat) => (
                    <div key={cat} className="flex items-center">
                      <input
                        type="checkbox"
                        id={cat}
                        className="h-4 w-4 text-primary-500 border-gray-300 rounded focus:ring-primary-500"
                      />
                      <label htmlFor={cat} className="ml-2 text-gray-700 capitalize">
                        {cat.replace('-', ' ')}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div>
              <h3 className="text-lg font-medium mb-3">Size</h3>
              <div className="grid grid-cols-3 gap-2">
                {(category === 'clothing'
                  ? ['S', 'M', 'L', 'XL', 'XXL']
                  : ['7', '8', '9', '10', '11', '12', '13']).map((size) => (
                  <div
                    key={size}
                    className="border border-gray-300 rounded-md p-2 text-center text-gray-700 hover:border-primary-500 hover:bg-primary-50 cursor-pointer"
                  >
                    {size}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Mobile Filters */}
        {showFilters && (
          <div className="fixed inset-0 bg-white z-50 overflow-auto p-4 md:hidden">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-medium">Filters</h2>
              <button
                onClick={() => setShowFilters(false)}
                className="p-2 text-gray-500"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-3">Price Range</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>${priceRange[0]}</span>
                    <span>${priceRange[1]}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="200"
                    value={priceRange[1]}
                    onChange={(e) => handlePriceChange([priceRange[0], parseInt(e.target.value)])}
                    className="w-full"
                  />
                </div>
              </div>
              
              {category === 'clothing' && (
                <div>
                  <h3 className="text-lg font-medium mb-3">Category</h3>
                  <div className="space-y-2">
                    {['t-shirts', 'pants', 'hoodies', 'shirts', 'jackets'].map((cat) => (
                      <div key={cat} className="flex items-center">
                        <input
                          type="checkbox"
                          id={`mobile-${cat}`}
                          className="h-4 w-4 text-primary-500 border-gray-300 rounded focus:ring-primary-500"
                        />
                        <label htmlFor={`mobile-${cat}`} className="ml-2 text-gray-700 capitalize">
                          {cat.replace('-', ' ')}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <div>
                <h3 className="text-lg font-medium mb-3">Size</h3>
                <div className="grid grid-cols-4 gap-2">
                  {(category === 'clothing'
                    ? ['S', 'M', 'L', 'XL', 'XXL']
                    : ['7', '8', '9', '10', '11', '12', '13']).map((size) => (
                    <div
                      key={`mobile-${size}`}
                      className="border border-gray-300 rounded-md p-2 text-center text-gray-700 hover:border-primary-500 hover:bg-primary-50 cursor-pointer"
                    >
                      {size}
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="pt-4">
                <button
                  onClick={() => setShowFilters(false)}
                  className="w-full bg-primary-500 text-secondary-900 py-3 rounded-md font-medium"
                >
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Products */}
        <div className="flex-1">
          <ProductGrid products={products} />
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;