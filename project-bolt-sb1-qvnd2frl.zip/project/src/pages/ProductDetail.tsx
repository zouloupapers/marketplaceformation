import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ShoppingBag, Heart, Share2, Star } from 'lucide-react';
import { getProductById } from '../data/products';
import Button from '../components/ui/Button';
import { useCart } from '../context/CartContext';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const product = getProductById(Number(id));
  const { addToCart } = useCart();
  
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>(product?.colors?.[0] || '');
  const [quantity, setQuantity] = useState(1);
  const [currentImage, setCurrentImage] = useState(0);
  const [error, setError] = useState('');

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-semibold mb-4">Product not found</h2>
        <p className="mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => navigate('/')}>
          Back to Home
        </Button>
      </div>
    );
  }

  const handleAddToCart = () => {
    if (!selectedSize) {
      setError('Please select a size');
      return;
    }
    
    addToCart(product, quantity, selectedSize, selectedColor);
    setError('');
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="bg-gray-100 rounded-lg overflow-hidden">
            <img
              src={product.images[currentImage]}
              alt={product.name}
              className="w-full h-96 object-cover object-center"
            />
          </div>
          
          {product.images.length > 1 && (
            <div className="flex space-x-2 overflow-x-auto py-2">
              {product.images.map((image, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentImage(idx)}
                  className={`flex-shrink-0 w-20 h-20 rounded-md overflow-hidden border-2 ${
                    idx === currentImage ? 'border-primary-500' : 'border-gray-200'
                  }`}
                >
                  <img
                    src={image}
                    alt={`${product.name} view ${idx + 1}`}
                    className="w-full h-full object-cover object-center"
                  />
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-serif font-semibold text-secondary-800">{product.name}</h1>
            <p className="mt-2 text-2xl font-bold text-secondary-700">${product.price.toFixed(2)}</p>
            
            {/* Rating */}
            {product.rating && (
              <div className="flex items-center mt-2">
                <div className="flex text-primary-500">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      size={16}
                      fill={i < Math.floor(product.rating) ? 'currentColor' : 'none'}
                    />
                  ))}
                </div>
                <span className="ml-2 text-gray-500 text-sm">
                  {product.rating.toFixed(1)} rating
                </span>
              </div>
            )}
          </div>
          
          <p className="text-gray-600">{product.description}</p>
          
          {/* Product Options */}
          <div className="space-y-6">
            {/* Color Selection */}
            {product.colors && product.colors.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-secondary-800">Color</h3>
                <div className="flex space-x-2 mt-2">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-3 py-1 border rounded-md ${
                        selectedColor === color
                          ? 'border-primary-500 bg-primary-50 text-primary-700'
                          : 'border-gray-300 text-gray-700'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Size Selection */}
            <div>
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-secondary-800">Size</h3>
                <button className="text-xs text-primary-500 hover:text-primary-600">
                  Size Guide
                </button>
              </div>
              <div className="grid grid-cols-4 gap-2 mt-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => {
                      setSelectedSize(size);
                      setError('');
                    }}
                    className={`px-3 py-2 text-center border rounded-md ${
                      selectedSize === size
                        ? 'border-primary-500 bg-primary-50 text-primary-700'
                        : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
              {error && <p className="text-accent-500 text-sm mt-1">{error}</p>}
            </div>
            
            {/* Quantity Selection */}
            <div>
              <h3 className="text-sm font-medium text-secondary-800">Quantity</h3>
              <div className="flex items-center mt-2">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2 border border-gray-300 rounded-l-md text-gray-600 hover:bg-gray-50"
                >
                  -
                </button>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                  className="w-16 text-center py-2 border-t border-b border-gray-300"
                />
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-2 border border-gray-300 rounded-r-md text-gray-600 hover:bg-gray-50"
                >
                  +
                </button>
              </div>
            </div>
          </div>
          
          {/* Actions */}
          <div className="flex space-x-4 pt-4">
            <Button
              onClick={handleAddToCart}
              fullWidth
              size="lg"
              className="flex items-center justify-center"
            >
              <ShoppingBag size={20} className="mr-2" />
              Add to Cart
            </Button>
            
            <button className="p-3 border border-gray-300 rounded-md text-gray-600 hover:bg-gray-50">
              <Heart size={20} />
            </button>
            
            <button className="p-3 border border-gray-300 rounded-md text-gray-600 hover:bg-gray-50">
              <Share2 size={20} />
            </button>
          </div>
          
          <div className="border-t border-gray-200 pt-4 text-sm text-gray-500">
            <p className="flex items-center">
              <span className="w-4 h-4 bg-green-500 rounded-full inline-block mr-2"></span>
              In stock and ready to ship
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;