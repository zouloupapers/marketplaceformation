import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';
import Button from '../components/ui/Button';

const CheckoutSuccess: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-sm p-8 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 rounded-full mb-6">
          <CheckCircle size={32} className="text-primary-500" />
        </div>
        
        <h1 className="text-2xl font-serif font-semibold mb-4">Order Placed Successfully!</h1>
        
        <p className="text-gray-600 mb-6">
          Thank you for your purchase! Your order has been received and is being processed.
          You will receive a confirmation email shortly with your order details.
        </p>
        
        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <h3 className="font-medium mb-2">Order Information</h3>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Order Number:</span>
            <span className="font-medium">SH{Math.floor(Math.random() * 1000000)}</span>
          </div>
          <div className="flex justify-between text-sm mt-1">
            <span className="text-gray-500">Date:</span>
            <span className="font-medium">{new Date().toLocaleDateString()}</span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <Link to="/">
            <Button variant="primary" fullWidth>
              Continue Shopping
            </Button>
          </Link>
          <Link to="/account/orders">
            <Button variant="outline" fullWidth>
              View Orders
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CheckoutSuccess;