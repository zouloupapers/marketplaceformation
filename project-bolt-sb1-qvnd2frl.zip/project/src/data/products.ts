import { Product } from '../types';

export const products: Product[] = [
  {
    id: 1,
    name: 'Premium Cotton T-Shirt',
    price: 29.99,
    category: 'clothing',
    subCategory: 't-shirts',
    description: 'High-quality cotton t-shirt with a comfortable fit. Perfect for everyday wear with its breathable fabric and stylish design.',
    images: [
      'https://images.pexels.com/photos/5384423/pexels-photo-5384423.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/5698851/pexels-photo-5698851.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Black', 'White', 'Navy'],
    featured: true,
    inStock: true,
    rating: 4.5
  },
  {
    id: 2,
    name: 'Slim Fit Jeans',
    price: 49.99,
    category: 'clothing',
    subCategory: 'pants',
    description: 'Classic slim fit jeans with a modern touch. Made from durable denim with just the right amount of stretch for comfort.',
    images: [
      'https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/934070/pexels-photo-934070.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    sizes: ['28', '30', '32', '34', '36'],
    colors: ['Blue', 'Black', 'Grey'],
    inStock: true,
    rating: 4.2
  },
  {
    id: 3,
    name: 'Urban Street Sneakers',
    price: 89.99,
    category: 'sneakers',
    description: 'Trendy urban sneakers with superior cushioning and support. Perfect for both casual wear and light athletic activities.',
    images: [
      'https://images.pexels.com/photos/1598505/pexels-photo-1598505.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1456706/pexels-photo-1456706.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    sizes: ['7', '8', '9', '10', '11', '12'],
    colors: ['White/Red', 'Black/White', 'Grey/Blue'],
    featured: true,
    new: true,
    inStock: true,
    rating: 4.8
  },
  {
    id: 4,
    name: 'Casual Hoodie',
    price: 59.99,
    category: 'clothing',
    subCategory: 'hoodies',
    description: 'Warm and comfortable hoodie perfect for those chilly days. Features a soft inner lining and adjustable hood.',
    images: [
      'https://images.pexels.com/photos/5698855/pexels-photo-5698855.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/5698908/pexels-photo-5698908.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Grey', 'Black', 'Navy', 'Burgundy'],
    inStock: true,
    rating: 4.3
  },
  {
    id: 5,
    name: 'Performance Running Shoes',
    price: 119.99,
    category: 'sneakers',
    description: 'Lightweight running shoes designed for performance. Features responsive cushioning and breathable mesh upper.',
    images: [
      'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/2421374/pexels-photo-2421374.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    sizes: ['7', '8', '9', '10', '11', '12'],
    colors: ['Black/Yellow', 'Blue/White', 'Red/Black'],
    featured: true,
    inStock: true,
    rating: 4.7
  },
  {
    id: 6,
    name: 'Classic Oxford Shirt',
    price: 44.99,
    category: 'clothing',
    subCategory: 'shirts',
    description: 'Timeless oxford shirt that never goes out of style. Made from premium cotton with a comfortable regular fit.',
    images: [
      'https://images.pexels.com/photos/297933/pexels-photo-297933.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/6626903/pexels-photo-6626903.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['White', 'Light Blue', 'Pink'],
    inStock: true,
    rating: 4.1
  },
  {
    id: 7,
    name: 'High-Top Basketball Sneakers',
    price: 129.99,
    category: 'sneakers',
    description: 'Professional-grade basketball sneakers with ankle support and responsive cushioning for optimal performance on the court.',
    images: [
      'https://images.pexels.com/photos/1670766/pexels-photo-1670766.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1661471/pexels-photo-1661471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    sizes: ['7', '8', '9', '10', '11', '12', '13'],
    colors: ['Black/Red', 'White/Blue', 'Grey/Orange'],
    new: true,
    inStock: true,
    rating: 4.9
  },
  {
    id: 8,
    name: 'Leather Bomber Jacket',
    price: 199.99,
    category: 'clothing',
    subCategory: 'jackets',
    description: 'Classic leather bomber jacket with a modern twist. Features premium leather construction and a comfortable quilted lining.',
    images: [
      'https://images.pexels.com/photos/1336873/pexels-photo-1336873.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1124468/pexels-photo-1124468.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Brown', 'Black'],
    featured: true,
    inStock: true,
    rating: 4.6
  }
];

export const getFeaturedProducts = (): Product[] => {
  return products.filter(product => product.featured);
};

export const getNewArrivals = (): Product[] => {
  return products.filter(product => product.new);
};

export const getProductsByCategory = (category: 'clothing' | 'sneakers'): Product[] => {
  return products.filter(product => product.category === category);
};

export const getProductById = (id: number): Product | undefined => {
  return products.find(product => product.id === id);
};